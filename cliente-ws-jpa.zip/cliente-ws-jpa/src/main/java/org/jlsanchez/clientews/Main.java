package org.jlsanchez.clientews;


import org.jlsanchez.webapp.jaxws.services.Curso;
import org.jlsanchez.webapp.jaxws.services.CursoServicioWs;
import org.jlsanchez.webapp.jaxws.services.CursoServicioWsImplService;


public class Main {
    public static void main(String[] args) {

   CursoServicioWs service = new CursoServicioWsImplService().getCursoServicioWsImplPort();

        Curso curso = new Curso();
        curso.setNombre("react");
        curso.setDescripcion("curso react");
        curso.setInstructor("Andres Guzman");
        curso.setDuracion(10D);

        Curso respuesta = service.crear(curso);
        System.out.println("nuevo curso: " + curso.getNombre());

        service.listar().forEach(c -> System.out.println(c.getNombre()));


    }
}
